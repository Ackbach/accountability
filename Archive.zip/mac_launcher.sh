#!/bin/bash
python /Users/m210028/Projects/old_projects/accountability/main.py
