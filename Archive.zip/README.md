# accountability
Simple Python script for getting screenshots and saving to a (typically cloud) folder.
